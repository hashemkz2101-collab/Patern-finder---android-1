plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

android {
    namespace = "ir.patternfinder.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "ir.patternfinder.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.2.0"
        // فقط گوشی‌های ۶۴ بیتی (S23 Ultra = arm64-v8a) → حجم APK کمتر
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

chaquopy {
    defaultConfig {
        // Chaquopy برای اندروید فقط opencv-python-headless 4.5.1.48 را (برای پایتون 3.8 و 3.10) دارد؛
        // نسخهٔ جدیدتر روی PyPI فقط کد منبع است و در GitHub Actions ساخته نمی‌شود.
        version = "3.10"
        pip {
            install("numpy")
            install("opencv-python-headless==4.5.1.48")
            install("Pillow")
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
