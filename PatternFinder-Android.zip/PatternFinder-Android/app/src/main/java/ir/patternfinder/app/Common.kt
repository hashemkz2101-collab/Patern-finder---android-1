package ir.patternfinder.app

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.width
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.material3.ExperimentalMaterial3Api

@Composable
fun Picker(label: String, value: String, options: List<Pair<String, String>>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { open = true }) {
            Text("$label: ${options.firstOrNull { it.first == value }?.second ?: value}", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (k, v) ->
                DropdownMenuItem(text = { Text(v) }, onClick = { onPick(k); open = false })
            }
        }
    }
}

@Composable
fun BusyBar(vm: AppViewModel) {
    if (!vm.busy) return
    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Text(vm.busyTitle + (if (vm.progMsg.isNotEmpty()) " — ${vm.progMsg}" else ""), style = MaterialTheme.typography.bodyMedium)
            if (vm.progN > 0) {
                LinearProgressIndicator(progress = { (vm.progI.toFloat() / vm.progN).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
                Text("${vm.progI} / ${vm.progN}", style = MaterialTheme.typography.labelMedium)
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
            }
            TextButton(onClick = { vm.cancelJob() }) { Text("لغو") }
        }
    }
}

@Composable
fun MessageDialog(vm: AppViewModel) {
    val m = vm.message ?: return
    AlertDialog(
        onDismissRequest = { vm.message = null },
        confirmButton = { TextButton(onClick = { vm.message = null }) { Text("باشه") } },
        text = { Text(m, modifier = Modifier.horizontalScroll(rememberScrollState())) },
    )
}

private fun hintFor(m: DrawMode): String = when (m) {
    DrawMode.PAN -> "یک انگشت: جابه‌جایی — دو انگشت: زوم — لمس قطعه: انتخاب"
    DrawMode.SMART -> "روی طرح بزنید تا کل قطعه (اجزای نزدیک‌به‌هم) انتخاب شود. نزدیکی را با اسلایدر تنظیم کنید."
    DrawMode.MAGNET -> "دور طرح نقطه بزنید؛ مسیر خودکار به لبهٔ طرح می‌چسبد. در پایان «پایان» را بزنید."
    DrawMode.RECT -> "با کشیدن انگشت یک مستطیل بکشید."
    DrawMode.POLY -> "رأس‌ها را یکی‌یکی لمس کنید و در پایان «پایان» را بزنید."
    DrawMode.CUT -> "ابتدا قطعه را انتخاب کنید؛ سپس با انگشت خطی از این طرف تا آن طرف محل اتصال بکشید تا قطعه همان‌جا جدا شود."
}

/** نوار ابزار ویرایش قطعات: حرکت / هوشمند / آهنربایی / مستطیل / چندضلعی / برش / حذف / جایگزینی */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegionToolbar(ed: RegionEditor, vm: AppViewModel, ctx: String) {
    fun pick(m: DrawMode) { ed.mode = m; ed.cancelPoly() }
    Column {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterChip(selected = ed.mode == DrawMode.PAN, onClick = { pick(DrawMode.PAN) }, label = { Text("✋ حرکت/انتخاب") })
            FilterChip(selected = ed.mode == DrawMode.SMART, onClick = { pick(DrawMode.SMART) }, label = { Text("👆 هوشمند") })
            FilterChip(selected = ed.mode == DrawMode.MAGNET, onClick = { pick(DrawMode.MAGNET) }, label = { Text("🧲 آهنربایی") })
            FilterChip(selected = ed.mode == DrawMode.RECT, onClick = { pick(DrawMode.RECT) }, label = { Text("▭ مستطیل") })
            FilterChip(selected = ed.mode == DrawMode.POLY, onClick = { pick(DrawMode.POLY) }, label = { Text("⬠ چندضلعی") })
            FilterChip(selected = ed.mode == DrawMode.CUT, onClick = { pick(DrawMode.CUT) }, label = { Text("✂ برش") })
            if (ed.mode == DrawMode.POLY) {
                OutlinedButton(onClick = { if (!ed.finishPoly()) vm.message = "حداقل ۳ نقطه لازم است." }) { Text("پایان") }
                OutlinedButton(onClick = { ed.undoPoint() }) { Text("برگردان") }
                OutlinedButton(onClick = { ed.cancelPoly() }) { Text("لغو") }
            }
            if (ed.mode == DrawMode.MAGNET) {
                OutlinedButton(onClick = { vm.magnetFinish(ctx) }) { Text("پایان") }
                OutlinedButton(onClick = { vm.magnetUndo(ctx) }) { Text("برگردان") }
                OutlinedButton(onClick = { ed.clearMagnet() }) { Text("لغو") }
            }
            OutlinedButton(onClick = { ed.deleteSel() }, enabled = ed.sel in ed.regions.indices) { Text("🗑 حذف") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = ed.replace, onCheckedChange = { ed.replace = it })
                Text("جایگزینی قطعهٔ انتخابی", style = MaterialTheme.typography.bodySmall)
            }
        }
        Text(hintFor(ed.mode), Modifier.padding(horizontal = 10.dp, vertical = 2.dp), style = MaterialTheme.typography.labelSmall)
    }
}

/** پیش‌پردازش، زمینه و «نزدیکی قطعات» + دکمهٔ تشخیص دوباره. */
@Composable
fun ModeRow(labels: Labels, mode: String, pol: String, vm: AppViewModel, onApply: (String, String) -> Unit) {
    var m by remember(mode) { mutableStateOf(mode) }
    var p by remember(pol) { mutableStateOf(pol) }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically,
    ) {
        Picker("پیش‌پردازش", m, labels.modes) { m = it }
        Picker("زمینه", p, labels.polarities) { p = it }
        Column(Modifier.width(170.dp)) {
            Text("نزدیکی قطعات: ${"%.1f".format(vm.mergeRatio * 100f)}٪", style = MaterialTheme.typography.labelSmall)
            Slider(value = vm.mergeRatio * 1000f, onValueChange = { vm.mergeRatio = it / 1000f }, valueRange = 2f..40f)
        }
        Button(onClick = { onApply(m, p) }) { Text("تشخیص دوباره") }
    }
}
