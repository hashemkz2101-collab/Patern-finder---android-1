"""تطبیق «خانه‌ای» برای طرح‌های پیکسلی.

طرح‌ها شبکه‌ای از خانه‌های هم‌اندازه‌اند. اندازهٔ خانه را از طول رانی‌ها تخمین می‌زنیم،
هر قطعه را به اندازهٔ خانهٔ ثابت (CELL_PX) می‌بریم و بعد همبستگی (NCC) را در چند چرخش/قرینه/مقیاس
جست‌وجو می‌کنیم. بنابراین مقیاس عکس، و نیمه‌دیده بودن قطعه مهم نیست.
مرحلهٔ دوم، برای چند نامزد برتر، با ECC (تبدیل آفین) هم‌ترازی دقیق‌تری می‌کند.
"""
from __future__ import annotations

import cv2
import numpy as np

CELL_PX = 4.0          # اندازهٔ هر خانه در نمایش ذخیره‌شده
SIGMA = 0.25           # تاری نسبی (برحسب خانه)
MIN_CELL = 2.0
_SCALES_COARSE = (0.94, 1.0, 1.06)
_SCALES_FINE = (0.88, 0.94, 1.0, 1.06, 1.12)
_ANGLES_FINE = (-8, -4, 0, 4, 8)


# --------------------------------------------------------------------------- #
# اندازهٔ خانه
# --------------------------------------------------------------------------- #
def _run_lengths(m: np.ndarray) -> np.ndarray:
    """طول رانی‌های جوهر و فاصله‌های بین آن‌ها در همهٔ سطرها (برداری)."""
    b = np.pad((m > 0).astype(np.int8), ((0, 0), (1, 1)))
    d = np.diff(b, axis=1)
    rs, cs = np.nonzero(d == 1)
    re, ce = np.nonzero(d == -1)           # به همان ترتیب سطر-ستون
    ink = ce - cs
    same = rs[1:] == rs[:-1]
    gaps = (cs[1:] - ce[:-1])[same]
    return np.concatenate([ink, gaps])


def estimate_cell(mask: np.ndarray) -> float | None:
    r = np.concatenate([_run_lengths(mask), _run_lengths(np.ascontiguousarray(mask.T))])
    r = r[r >= 2]
    if len(r) < 20:
        return None
    hi = int(np.percentile(r, 95)) + 2
    h = np.bincount(r, minlength=hi + 1).astype(float)[:hi + 1]
    h = np.convolve(h, [1, 2, 3, 2, 1], "same")
    p = int(np.argmax(h))
    cand = [k for k in range(2, p + 1)
            if h[k] >= 0.5 * h[p] and h[k] >= h[k - 1] and h[k] >= h[min(k + 1, hi)]]
    c = float(cand[0] if cand else p)
    return c if c >= MIN_CELL else None


def normalize(mask: np.ndarray, cell: float, extra: float = 1.0, sigma: float = SIGMA) -> np.ndarray:
    """ماسک ۰/۲۵۵ -> تصویر float32 با خانهٔ CELL_PX پیکسلی و کمی تاری."""
    k = CELL_PX / cell * extra
    m = cv2.resize((mask > 0).astype(np.float32), None, fx=k, fy=k, interpolation=cv2.INTER_AREA)
    return cv2.GaussianBlur(m, (0, 0), max(0.5, CELL_PX * sigma))


def make_signature(mask: np.ndarray) -> tuple[float, np.ndarray] | None:
    """(اندازهٔ خانه، تصویر ۸بیتی نرمال‌شده) برای ذخیره در پایگاه. None اگر الگو شبکه‌ای نباشد."""
    c = estimate_cell(mask)
    if c is None:
        return None
    img = normalize(mask, c)
    if min(img.shape) < 6:
        return None
    return c, np.clip(img * 255, 0, 255).astype(np.uint8)


# --------------------------------------------------------------------------- #
# همبستگی
# --------------------------------------------------------------------------- #
def _ncc_best(a: np.ndarray, b: np.ndarray):
    """بهترین NCC قطعهٔ کوچک‌تر داخل بزرگ‌تر؛ پنجره‌های تقریباً خالی/بی‌معنی کنار گذاشته می‌شوند."""
    if a.shape[0] * a.shape[1] > b.shape[0] * b.shape[1]:
        a, b = b, a
    H, W = a.shape
    ph, pw = H // 2, W // 2
    B = cv2.copyMakeBorder(b, ph, ph, pw, pw, cv2.BORDER_CONSTANT, value=0)
    if B.shape[0] < H or B.shape[1] < W:
        return 0.0, None
    res = cv2.matchTemplate(B, a, cv2.TM_CCOEFF_NORMED)
    ink_t = float(a.sum())
    if ink_t <= 1e-6:
        return 0.0, None
    ii = cv2.integral(B)
    win = ii[H:, W:] - ii[:-H, W:] - ii[H:, :-W] + ii[:-H, :-W]
    win = win[:res.shape[0], :res.shape[1]]
    ok = (win >= 0.6 * ink_t) & (win <= 1.8 * ink_t)
    if not ok.any():
        return 0.0, None
    res = np.where(ok, res, -1)
    _, mx, _, loc = cv2.minMaxLoc(res)
    return float(mx), (loc, B, a)


def _orientations(img: np.ndarray):
    for flip in (False, True):
        base = np.fliplr(img) if flip else img
        for rot in range(4):
            yield np.ascontiguousarray(np.rot90(base, rot))


def coarse_score(q_img: np.ndarray, t_img: np.ndarray) -> float:
    """جست‌وجوی سریع: ۸ جهت × ۳ مقیاس. هر دو float32 با خانهٔ یکسان."""
    best = 0.0
    for ex in _SCALES_COARSE:
        q = q_img if ex == 1.0 else cv2.resize(q_img, None, fx=ex, fy=ex, interpolation=cv2.INTER_LINEAR)
        for qq in _orientations(q):
            s, _ = _ncc_best(qq, t_img)
            if s > best:
                best = s
    return best


def fine_score(q_mask: np.ndarray, q_cell: float, t_img: np.ndarray) -> float:
    """جست‌وجوی دقیق + هم‌ترازی ECC آفین؛ امتیاز ∈ [0,1]."""
    best, info = -1.0, None
    for ex in _SCALES_FINE:
        q0 = normalize(q_mask, q_cell, extra=ex)
        for ang in _ANGLES_FINE:
            if ang:
                h, w = q0.shape
                M = cv2.getRotationMatrix2D((w / 2, h / 2), ang, 1.0)
                q = cv2.warpAffine(q0, M, (w, h), flags=cv2.INTER_LINEAR)
            else:
                q = q0
            for qq in _orientations(q):
                s, inf = _ncc_best(qq, t_img)
                if s > best:
                    best, info = s, inf
    if info is None:
        return 0.0
    (x, y), B, a = info
    H, W = a.shape
    win = B[y:y + H, x:x + W].astype(np.float32)
    a32 = a.astype(np.float32)
    crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 60, 1e-5)
    try:
        M = np.eye(2, 3, dtype=np.float32)
        cc, M = cv2.findTransformECC(win, a32, M, cv2.MOTION_AFFINE, crit, None, 5)
        best = max(best, float(cc))
        # پرسپکتیو: از نتیجهٔ آفین شروع می‌کنیم
        Hm = np.vstack([M, [0, 0, 1]]).astype(np.float32)
        cc2, _ = cv2.findTransformECC(win, a32, Hm, cv2.MOTION_HOMOGRAPHY, crit, None, 5)
        best = max(best, float(cc2))
    except cv2.error:
        pass
    return float(max(0.0, best))


def to_similarity(cc: float) -> float:
    """نگاشت همبستگی (پایهٔ تصادفی ≈ ۰٫۴۵ تا ۰٫۵۵) به شباهت ۰..۱."""
    return float(min(1.0, max(0.0, (cc - 0.45) / 0.30)))
