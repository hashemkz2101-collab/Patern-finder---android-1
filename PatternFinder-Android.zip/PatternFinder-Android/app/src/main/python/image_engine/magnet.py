"""انتخاب آهنربایی (Magnetic Lasso): مسیر بین دو نقطه از روی لبهٔ طرح می‌گذرد.

نقشهٔ لبه از گرادیان تصویر خاکستری و ماسک باینری ساخته می‌شود؛ مسیر با الگوریتم
کوتاه‌ترین مسیر (Dijkstra) روی هزینهٔ «کم روی لبه، زیاد جای دیگر» پیدا می‌شود (live-wire).
"""
from __future__ import annotations

import heapq
import math
from typing import Optional

import cv2
import numpy as np


def edge_map(an) -> np.ndarray:
    """قدرت لبه ∈ [0,1]، به‌صورت کش‌شده روی شیء تحلیل."""
    cached = getattr(an, "_edge", None)
    if cached is not None:
        return cached
    gray = cv2.cvtColor(an.image, cv2.COLOR_BGR2GRAY) if an.image.ndim == 3 else an.image
    g = cv2.GaussianBlur(gray, (0, 0), 1.0).astype(np.float32)
    mag = np.hypot(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3), cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3))
    b = cv2.GaussianBlur(an.binary, (0, 0), 1.2).astype(np.float32) / 255.0
    bm = np.hypot(cv2.Sobel(b, cv2.CV_32F, 1, 0, ksize=3), cv2.Sobel(b, cv2.CV_32F, 0, 1, ksize=3))
    for m in (mag, bm):
        p = float(np.percentile(m, 99.5))
        m /= max(p, 1e-6)
    e = np.clip(np.maximum(mag, bm), 0.0, 1.0).astype(np.float32)
    try:
        an._edge = e
    except AttributeError:
        pass
    return e


def snap_point(an, x: float, y: float, radius: int = 6) -> tuple[int, int]:
    """نقطه را به قوی‌ترین لبهٔ نزدیک می‌چسباند (اگر لبهٔ واضحی نبود، همان نقطه)."""
    e = edge_map(an)
    H, W = e.shape
    xi = int(min(max(round(x), 0), W - 1))
    yi = int(min(max(round(y), 0), H - 1))
    x0, y0, x1, y1 = max(0, xi - radius), max(0, yi - radius), min(W, xi + radius + 1), min(H, yi + radius + 1)
    sub = e[y0:y1, x0:x1]
    yy, xx = np.mgrid[y0:y1, x0:x1]
    d2 = (xx - xi) ** 2 + (yy - yi) ** 2
    score = sub * (1.0 - 0.5 * d2 / float(radius * radius + 1))
    score[d2 > radius * radius] = -1
    j = int(np.argmax(score))
    sy, sx = divmod(j, sub.shape[1])
    if sub[sy, sx] < 0.25:
        return xi, yi
    return int(x0 + sx), int(y0 + sy)


_NB = ((-1, 0, 1.0), (1, 0, 1.0), (0, -1, 1.0), (0, 1, 1.0),
       (-1, -1, 1.4142), (1, -1, 1.4142), (-1, 1, 1.4142), (1, 1, 1.4142))


def _dijkstra(cost: np.ndarray, s: tuple[int, int], t: tuple[int, int], max_pops: int = 500_000) -> Optional[list]:
    h, w = cost.shape
    flat = cost.ravel().tolist()
    si, ti = s[1] * w + s[0], t[1] * w + t[0]
    inf = 1e18
    dist = [inf] * (w * h)
    prev = [-1] * (w * h)
    dist[si] = 0.0
    heap = [(0.0, si)]
    pops = 0
    while heap:
        d, u = heapq.heappop(heap)
        if d > dist[u]:
            continue
        if u == ti:
            break
        pops += 1
        if pops > max_pops:
            return None
        ux, uy = u % w, u // w
        for dx, dy, mul in _NB:
            vx, vy = ux + dx, uy + dy
            if vx < 0 or vy < 0 or vx >= w or vy >= h:
                continue
            v = vy * w + vx
            nd = d + flat[v] * mul
            if nd < dist[v]:
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, v))
    if prev[ti] < 0 and ti != si:
        return None
    path = []
    u = ti
    while u != -1:
        path.append((u % w, u // w))
        u = prev[u]
    path.reverse()
    return path


def live_wire(an, a: tuple[float, float], b: tuple[float, float], snap_end: bool = True) -> dict:
    """مسیر چسبیده به لبه از a تا b. خروجی: {"path": [[x,y],...], "end": [x,y]}."""
    e = edge_map(an)
    H, W = e.shape
    s = (int(min(max(round(a[0]), 0), W - 1)), int(min(max(round(a[1]), 0), H - 1)))
    t = snap_point(an, b[0], b[1]) if snap_end else (int(round(b[0])), int(round(b[1])))
    if s == t:
        return {"path": [list(s)], "end": list(t)}
    dist = math.hypot(t[0] - s[0], t[1] - s[1])
    m = int(max(25, 0.3 * dist))
    x0, y0 = max(0, min(s[0], t[0]) - m), max(0, min(s[1], t[1]) - m)
    x1, y1 = min(W, max(s[0], t[0]) + m + 1), min(H, max(s[1], t[1]) + m + 1)
    sub = e[y0:y1, x0:x1]
    cost = (0.04 + (1.0 - sub) ** 2).astype(np.float32)
    f = 2 if cost.size > 180_000 else 1
    if f == 2:
        cost = cv2.resize(cost, (max(2, cost.shape[1] // 2), max(2, cost.shape[0] // 2)), interpolation=cv2.INTER_AREA)
    sl = ((s[0] - x0) // f, (s[1] - y0) // f)
    tl = ((t[0] - x0) // f, (t[1] - y0) // f)
    sl = (min(sl[0], cost.shape[1] - 1), min(sl[1], cost.shape[0] - 1))
    tl = (min(tl[0], cost.shape[1] - 1), min(tl[1], cost.shape[0] - 1))
    path = _dijkstra(cost, sl, tl)
    if path is None:                           # مسیر پیدا نشد: خط راست
        pts = [list(s), list(t)]
    else:
        pts = [[x0 + p[0] * f, y0 + p[1] * f] for p in path]
        pts[0] = list(s)
        pts[-1] = list(t)
        if len(pts) > 2:
            ap = cv2.approxPolyDP(np.array(pts, np.int32).reshape(-1, 1, 2), 0.9, False)
            pts = [[int(q[0][0]), int(q[0][1])] for q in ap]
    return {"path": pts, "end": list(t)}
