"""تشخیص خودکار قطعات (اجزای مجزا) و کار با نواحی انتخابی کاربر."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional

import cv2
import numpy as np


@dataclass
class Region:
    """یک قطعه؛ مستطیل (x,y,w,h) و در صورت نیاز چندضلعی (مختصات تصویر کاری)."""

    x: int
    y: int
    w: int
    h: int
    polygon: Optional[list] = None  # [(x, y), ...]
    source: str = "auto"            # auto | manual
    area: int = 0

    @property
    def bbox(self) -> tuple[int, int, int, int]:
        return (self.x, self.y, self.w, self.h)

    @classmethod
    def from_rect(cls, x, y, w, h, source="manual") -> "Region":
        return cls(int(x), int(y), int(w), int(h), None, source)

    @classmethod
    def from_polygon(cls, pts: Iterable, source="manual") -> "Region":
        p = [(int(round(a)), int(round(b))) for a, b in pts]
        arr = np.array(p, dtype=np.int32)
        x, y, w, h = cv2.boundingRect(arr)
        return cls(x, y, max(1, w), max(1, h), p, source)

    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y, "w": self.w, "h": self.h,
                "polygon": self.polygon, "source": self.source}

    def outline(self) -> list:
        if self.polygon:
            return list(self.polygon)
        return [(self.x, self.y), (self.x + self.w, self.y),
                (self.x + self.w, self.y + self.h), (self.x, self.y + self.h)]


def _odd(n: float) -> int:
    n = int(max(3, round(n)))
    return n if n % 2 else n + 1


def mask_from_region(binary: np.ndarray, region: Region) -> Optional[tuple[np.ndarray, tuple[int, int]]]:
    """ماسک فشردهٔ قطعه و مختصات گوشهٔ بالا-چپ آن در تصویر. اگر خالی بود None."""
    H, W = binary.shape[:2]
    x0, y0 = max(0, region.x), max(0, region.y)
    x1, y1 = min(W, region.x + region.w), min(H, region.y + region.h)
    if x1 <= x0 or y1 <= y0:
        return None
    if region.polygon and len(region.polygon) >= 3:
        pm = np.zeros((H, W), np.uint8)
        cv2.fillPoly(pm, [np.array(region.polygon, np.int32)], 255)
        sub = cv2.bitwise_and(binary[y0:y1, x0:x1], pm[y0:y1, x0:x1])
    else:
        sub = binary[y0:y1, x0:x1].copy()
    pts = cv2.findNonZero(sub)
    if pts is None:
        return None
    bx, by, bw, bh = cv2.boundingRect(pts)
    return sub[by:by + bh, bx:bx + bw].copy(), (x0 + bx, y0 + by)


def union_mask(binary: np.ndarray, regions: list[Region]) -> Optional[tuple[np.ndarray, tuple[int, int]]]:
    """اجتماع ماسک چند قطعه (برای ویژگی‌های «کل طرح»). بدون قطعه: کل باینری."""
    H, W = binary.shape[:2]
    if not regions:
        acc = binary
    else:
        acc = np.zeros((H, W), np.uint8)
        for r in regions:
            res = mask_from_region(binary, r)
            if res is None:
                continue
            m, (ox, oy) = res
            acc[oy:oy + m.shape[0], ox:ox + m.shape[1]] |= m
    pts = cv2.findNonZero(acc)
    if pts is None:
        return None
    bx, by, bw, bh = cv2.boundingRect(pts)
    return acc[by:by + bh, bx:bx + bw].copy(), (bx, by)


def _ellipse(k: int) -> np.ndarray:
    return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (int(k), int(k)))


def tight_polygon(ink: np.ndarray, ox: int, oy: int, k: int, margin: int = 2) -> Optional[list]:
    """چندضلعی‌ای که دقیقاً دور طرح می‌نشیند (نه جعبهٔ شل).

    ink: ماسک ۰/۲۵۵ فشردهٔ قطعه، (ox, oy): مختصات گوشهٔ آن در تصویر.
    خطوط نزدیک هم با «بستن» (closing) به هم وصل می‌شوند تا کانتور یکپارچه شود، سپس
    کمی (margin) بزرگ می‌شود تا هیچ پیکسل طرحی بیرون نماند.
    """
    pad = int(k) + int(margin) + 3
    m = cv2.copyMakeBorder(ink, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=0)
    if k >= 3:
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, _ellipse(k))
    if margin > 0:
        m = cv2.dilate(m, _ellipse(2 * int(margin) + 1))
    cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cs:
        return None
    if len(cs) > 1:   # جزیرهٔ جدامانده (نادر): پوستهٔ محدب همهٔ نقاط
        c = cv2.convexHull(np.concatenate(cs))
    else:
        c = cs[0]
    arc = cv2.arcLength(c, True)
    ap = cv2.approxPolyDP(c, max(0.8, 0.0010 * arc), True)
    if len(ap) < 3:
        return None
    return [(int(p[0][0]) - pad + ox, int(p[0][1]) - pad + oy) for p in ap]


def _region_from_ink(ink: np.ndarray, ox: int, oy: int, k_close: int, source: str,
                     margin: int = 2) -> Optional[Region]:
    """ink: ماسک ۰/۲۵۵ (هر اندازه)؛ (ox, oy) محل گوشهٔ آن در تصویر."""
    pts = cv2.findNonZero(ink)
    if pts is None:
        return None
    bx, by, bw, bh = cv2.boundingRect(pts)
    sub = ink[by:by + bh, bx:bx + bw]
    area = int(cv2.countNonZero(sub))
    poly = tight_polygon(sub, ox + bx, oy + by, k_close, margin)
    return Region(ox + bx, oy + by, bw, bh, poly, source, area)


def _group_ink(binary: np.ndarray, labels: np.ndarray, stats: np.ndarray, i: int):
    """ماسک طرحِ گروه i (برش‌خورده) و گوشهٔ آن."""
    gx, gy, gw, gh = (int(v) for v in stats[i, :4])
    lab = labels[gy:gy + gh, gx:gx + gw] == i
    ink = np.where(lab, binary[gy:gy + gh, gx:gx + gw], 0).astype(np.uint8)
    return ink, gx, gy


def detect_regions(
    binary: np.ndarray,
    merge_ratio: float = 0.010,
    min_rel_area: float = 0.03,
    min_abs_ratio: float = 0.0003,
    max_regions: int = 40,
) -> list[Region]:
    """اجزای نزدیک به هم یک قطعه حساب می‌شوند (merge_ratio نسبت به بزرگ‌ترین ضلع).

    merge_ratio کوچک‌تر = قطعات بیشتر و جداتر؛ بزرگ‌تر = قطعات نزدیک به هم یکی می‌شوند.
    """
    H, W = binary.shape[:2]
    if not np.any(binary):
        return []
    k = _odd(merge_ratio * max(H, W))
    dil = cv2.dilate(binary, _ellipse(k))
    n, labels, stats, _ = cv2.connectedComponentsWithStats(dil, connectivity=8)

    cands: list[tuple[int, Region]] = []
    for i in range(1, n):
        ink, gx, gy = _group_ink(binary, labels, stats, i)
        area = int(cv2.countNonZero(ink))
        if area == 0:
            continue
        bx, by, bw, bh = cv2.boundingRect(cv2.findNonZero(ink))
        # قاب اسکنر / حاشیهٔ بزرگ و توخالی را کنار بگذار
        if bw > 0.95 * W and bh > 0.95 * H and area < 0.25 * bw * bh:
            continue
        reg = _region_from_ink(ink, gx, gy, k + 2, "auto")
        if reg is not None:
            cands.append((area, reg))

    if not cands:
        return []
    biggest = max(a for a, _ in cands)
    thr = max(min_abs_ratio * H * W, min_rel_area * biggest)
    kept = [r for a, r in cands if a >= thr]
    kept.sort(key=lambda r: -r.area)
    kept = kept[:max_regions]
    band = max(1.0, H / 6.0)
    kept.sort(key=lambda r: (round((r.y + r.h / 2) / band), r.x))
    return kept


# --------------------------------------------------------------------------- #
# انتخاب هوشمند (لمس طرح)
# --------------------------------------------------------------------------- #
def pick_region(binary: np.ndarray, x: float, y: float, merge_ratio: float = 0.010,
                radius: Optional[int] = None) -> Optional[Region]:
    """قطعهٔ زیر انگشت: همان گروه از اجزای نزدیک‌به‌هم که روی نقطه (یا نزدیک‌ترین طرح) است."""
    H, W = binary.shape[:2]
    xi, yi = int(round(x)), int(round(y))
    if not (0 <= xi < W and 0 <= yi < H) or not np.any(binary):
        return None
    k = _odd(merge_ratio * max(H, W))
    px, py = xi, yi
    if binary[yi, xi] == 0:
        r = int(radius or max(12, 0.025 * max(H, W)))
        x0, y0, x1, y1 = max(0, xi - r), max(0, yi - r), min(W, xi + r + 1), min(H, yi + r + 1)
        ys, xs = np.nonzero(binary[y0:y1, x0:x1])
        if len(xs) == 0:
            return None
        d = (xs + x0 - xi) ** 2 + (ys + y0 - yi) ** 2
        j = int(np.argmin(d))
        if d[j] > r * r:
            return None
        px, py = int(xs[j] + x0), int(ys[j] + y0)
    dil = cv2.dilate(binary, _ellipse(k))
    _n, labels, stats, _ = cv2.connectedComponentsWithStats(dil, connectivity=8)
    lab = int(labels[py, px])
    if lab == 0:
        return None
    ink, gx, gy = _group_ink(binary, labels, stats, lab)
    return _region_from_ink(ink, gx, gy, k + 2, "smart")


# --------------------------------------------------------------------------- #
# برش قطعه
# --------------------------------------------------------------------------- #
def split_region(binary: np.ndarray, region: Region, stroke: list, merge_ratio: float = 0.010) -> list[Region]:
    """قطعه را با خطی که کاربر کشیده به دو یا چند قطعه تقسیم می‌کند.

    روش ۱: مسیر کشیده‌شده مانند دیواره‌ای نازک از طرح کم می‌شود و اجزای جداشده قطعهٔ جدیدند.
    روش ۲ (اگر دیواره جدا نکرد): خط راست از اولین تا آخرین نقطه تا بی‌نهایت امتداد می‌یابد.
    خروجی خالی = برش ممکن نبود.
    """
    H, W = binary.shape[:2]
    if len(stroke) < 2:
        return []
    k = _odd(merge_ratio * max(H, W))
    pad = k + 8
    x0, y0 = max(0, region.x - pad), max(0, region.y - pad)
    x1, y1 = min(W, region.x + region.w + pad), min(H, region.y + region.h + pad)
    if x1 <= x0 or y1 <= y0:
        return []
    ink = binary[y0:y1, x0:x1].copy()
    if region.polygon and len(region.polygon) >= 3:
        pm = np.zeros_like(ink)
        poly = np.array(region.polygon, np.int32) - np.array([x0, y0], np.int32)
        cv2.fillPoly(pm, [poly], 255)
        ink = cv2.bitwise_and(ink, pm)
    if cv2.countNonZero(ink) == 0:
        return []
    h, w = ink.shape
    pts = np.array([(float(a) - x0, float(b) - y0) for a, b in stroke], np.float32)
    t = max(3, int(round(0.004 * max(H, W))))
    kc = k + 2

    def finish(masks: list) -> list[Region]:
        out = []
        for m in masks:
            if cv2.countNonZero(m) < 8:
                continue
            r = _region_from_ink(m, x0, y0, kc, "split", margin=1)
            if r is not None:
                out.append(r)
        out.sort(key=lambda r: (r.x, r.y))
        return out if len(out) >= 2 else []

    # --- روش ۱: دیوارهٔ نازک ---
    p = pts.copy()
    for a, b in ((0, min(3, len(p) - 1)), (-1, max(-4, -len(p)))):
        d = p[a] - p[b]
        nrm = float(np.hypot(*d))
        if nrm > 1e-3:
            ext = p[a] + d / nrm * (2 * t)
            p = np.vstack([ext, p]) if a == 0 else np.vstack([p, ext])
    bar = np.zeros_like(ink)
    cv2.polylines(bar, [np.round(p).astype(np.int32).reshape(-1, 1, 2)], False, 255, t)
    D = cv2.dilate(ink, _ellipse(k))
    L = cv2.bitwise_and(D, cv2.bitwise_not(bar))
    n, lab, _st, _ = cv2.connectedComponentsWithStats(L, connectivity=8)
    keep = []
    for i in range(1, n):
        if cv2.countNonZero(cv2.bitwise_and(ink, (lab == i).astype(np.uint8) * 255)) >= 8:
            keep.append(i)
    if len(keep) >= 2:
        # هر پیکسل طرح (حتی زیر دیواره) به نزدیک‌ترین جزء نسبت داده می‌شود
        lab2 = np.zeros((h, w), np.int32)
        for j, i in enumerate(keep, 1):
            lab2[lab == i] = j
        src = (lab2 == 0).astype(np.uint8)
        _d, near = cv2.distanceTransformWithLabels(src, cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
        lut = np.zeros(int(near.max()) + 1, np.int32)
        zero = lab2 > 0
        lut[near[zero]] = lab2[zero]
        owner = lut[near]
        owner[zero] = lab2[zero]
        masks = [np.where((owner == j) & (ink > 0), 255, 0).astype(np.uint8) for j in range(1, len(keep) + 1)]
        res = finish(masks)
        if res:
            return res

    # --- روش ۲: خط راست نامحدود ---
    a, b = pts[0], pts[-1]
    if float(np.hypot(*(b - a))) < 2.0:
        return []
    yy, xx = np.mgrid[0:h, 0:w]
    side = (b[0] - a[0]) * (yy - a[1]) - (b[1] - a[1]) * (xx - a[0]) > 0
    ma = np.where(side & (ink > 0), 255, 0).astype(np.uint8)
    mb = np.where(~side & (ink > 0), 255, 0).astype(np.uint8)
    return finish([ma, mb])


def grow_polygon(polygon: list, px: int = 2) -> list:
    """چندضلعی را px پیکسل بزرگ می‌کند (برای اینکه لبهٔ طرح بیرون نماند)."""
    arr = np.array(polygon, np.int32)
    x0, y0 = arr.min(axis=0) - (px + 3)
    x1, y1 = arr.max(axis=0) + (px + 4)
    x0, y0 = int(max(x0, -10_000)), int(max(y0, -10_000))
    m = np.zeros((int(y1 - y0), int(x1 - x0)), np.uint8)
    cv2.fillPoly(m, [arr - np.array([x0, y0], np.int32)], 255)
    m = cv2.dilate(m, _ellipse(2 * px + 1))
    cs, _ = cv2.findContours(m, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cs:
        return [tuple(map(int, p)) for p in polygon]
    c = max(cs, key=cv2.contourArea)
    ap = cv2.approxPolyDP(c, 0.8, True)
    return [(int(p[0][0]) + x0, int(p[0][1]) + y0) for p in ap]
